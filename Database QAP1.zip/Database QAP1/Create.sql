CREATE TABLE Employee(
	employee_id SERIAL PRIMARY KEY,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	email VARCHAR(255),
	hire_date DATE,
	active BOOLEAN DEFAULT true,
	manager_id INT,
	FOREIGN KEY (manager_id) REFERENCES Employee(employee_id) ON DELETE SET NULL
);
CREATE TABLE Sale(
	sale_id SERIAL PRIMARY KEY,
	sale_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	amount NUMERIC(10,2) NOT NULL,
	employee_id INT NOT NULL,
	FOREIGN KEY (employee_id) REFERENCES Employee(employee_id) ON DELETE CASCADE
);