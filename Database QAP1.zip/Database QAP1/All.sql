SELECT
	p.customer_id,
	COUNT(p.payment_id) AS payment_count,
	SUM(p.amount) AS total_amount,
	i.film_id
FROM
	payment AS p
JOIN
	inventory AS i ON p.rental_id = i.inventory_id
WHERE
	p.amount>5
GROUP BY
	p.customer_id, i.film_id
ORDER BY
	total_amount DESC