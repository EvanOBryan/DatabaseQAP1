SELECT
	p.customer_id,
	COUNT(p.payment_id) AS payment_count,
	SUM(p.amount) AS total_amount,
	p.rental_id
FROM
	payment AS p
WHERE
	p.amount>5
GROUP BY
	p.customer_id, p.rental_id