SELECT
	p.payment_id,
	p.customer_id,
	p.amount,
	p.rental_id
FROM
	payment AS p
