INSERT INTO address (address_id, address, address2, district, city_id, postal_code, phone, last_update)
VALUES (611,'16 Dunfield Place', ' ', 'Heights', 1, 'A2H1T7','709-123-4567',NOW());
SELECT address_id INTO new2_address_id
	FROM address
	ORDER BY address_id DESC
	limit 1;
INSERT INTO customer (customer_id, store_id, first_name, last_name, email, address_id, activebool, create_date, last_update, active)
VALUES
(23459, 1, 'John', 'Doe', 'j.d1@email.com', (SELECT MAX(address_id) FROM address), true, NOW(), NOW(), 1),
(23460, 1, 'Jane', 'Doe', 'j.d2@email.com', (SELECT MAX(address_id) FROM address), true, NOW(), NOW(), 1),
(23461, 1, 'Jimmy', 'Doe', 'j.d3@email.com', (SELECT MAX(address_id) FROM address), true, NOW(), NOW(), 1);

UPDATE address
SET 
	address='123 New Street',
	district='Heights',
	postal_code='1A2B3C',
	phone='709-123-4567',
	last_update=NOW()
WHERE 
	address_id=611;

DELETE FROM address
WHERE
	address_id IN(
	SELECT address_id
	FROM customer
	WHERE last_name='Doe'
	)AND address_id!=611;



