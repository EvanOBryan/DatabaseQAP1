SELECT
	p.payment_id,
	p.customer_id,
	p.amount,
	i.film_id
FROM
	payment AS p
JOIN
	inventory AS i ON p.rental_id=i.inventory_id